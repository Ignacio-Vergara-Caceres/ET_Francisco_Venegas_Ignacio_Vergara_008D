export const environment = {
  apiUrl:'https://datajson-2.onrender.com',
  production: true
};

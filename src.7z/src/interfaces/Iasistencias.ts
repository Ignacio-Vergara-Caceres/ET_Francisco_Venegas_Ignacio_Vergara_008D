export interface Iasistencia{
    rut:number;
    id_evento: number;
    nombre: string;
    fecha: string;
    lugar:string;
    email:string;
}
export interface Iasistencias{
    id:number;
    rut:number;
    id_evento: number;
    nombre: string;
    fecha: string;
    lugar:string;
    email:string;

}
export interface Icomentario{
    idEvento:number;
    nombreEvento:string;
    nombreUsuario:string;
    comentario:string;
}